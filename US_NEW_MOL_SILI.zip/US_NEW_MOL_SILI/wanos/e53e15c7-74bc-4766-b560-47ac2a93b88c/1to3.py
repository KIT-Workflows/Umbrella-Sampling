f=open('seq','r')
l_f=f.readlines()
l=len(l_f[0])
g=open('one_to_three.dat','r')
l_g=g.readlines()
N=20
s=''
for i in range(0,l):
    for j in range(0,N):
        if l_f[0][i]==l_g[j][0]:
            s=s+l_g[j].split()[1]+' '
print s
