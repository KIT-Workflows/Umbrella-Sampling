cp /home/ws/kn1269/projects/adsorption/simstack/Graphene/* ./
cp -r /home/ws/kn1269/projects/adsorption/simstack/Graphene/mdp ./
mkdir MOL
cd MOL
cp ../MOL.pdb ./
cp ../mol.itp ./
# any comment 
cp ../input_* ./
cp ../INP* ./
cp ../*py ./
gmx trjconv -f MOL.pdb  -s MOL.pdb -o MOL.gro < input_0
gmx editconf -f MOL.gro -box 4.26000   4.18100   6.0000 -o MOL_boxed.gro
cp ../Graphene.gro ./
cp ../Graphene.itp ./
cp ../posre_Graphene.itp ./
cat Graphene.gro MOL_boxed.gro > system.gro
sed -i '2s/1360/1358/' system.gro  
sed -i '1363d' system.gro
sed -i '1363d' system.gro
sed -i '1363d' system.gro
cp ../topol.top ./
sed -i '33s/#include "xxx.itp"/#include "mol.itp"/' topol.top          
sed -i '50s/xxx                 1/mol                 1/' topol.top 
sed -i '4s/end=/end=-2/' write_posre.py  
python write_posre.py
gmx solvate -cp system.gro -p topol.top -o system_solv.gro
cp ../ions.mdp ./
gmx grompp -f ions.mdp -c system_solv.gro -p topol.top -o ions.tpr
gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral < input_1

gmx make_ndx -f solv_ions.gro -o index.ndx < input_2
python ndx.py
cat index.ndx ndx.dat  > index_out.ndx
cp -r ../mdp/ ./
mv index_out.ndx index.ndx
cp solv_ions.gro system.gro
cp ../run.sh ./
