# MyWaNo

**Version:** 1.0.0
**Author:** Me

## Description

This is a sample WaNo.


## Parameters

**Input File:**
* just a sample input file

### General Settings

**Print** (default: "Text")
* Determines wether the Number or the String will be printed

**Text:** (default: "Text")
* The String that will be printed

**Number:** (default: 10 )
* The Number that will be printed  
 

## Output
**output.txt** 
* the file including the output

**output.txt**

