#!/bin/bash

WORKING_DIR=`pwd`

protein=MOL
lower=$(echo $protein | awk '{print tolower($0)}')


var1=${protein}
no=$(wc -l *.pdb | awk '{ print $1 }')
a=$((no-1))
var2=`expr 4800 + $a` #Gold   no_of_atom + no_of_atom_in var1
cat>abc.sh<<EOF

cp /home/ws/kn1269/projects/adsorption/simstack/Gold/* ./
mkdir ${var1}
cd ${var1}
cp ../${var1}.pdb ./
cp ../${lower}.itp ./

cp ../input_* ./
cp ../*py ./
cp ../*sh ./
cp ../INP* ./
gmx trjconv -f ${var1}.pdb  -s ${var1}.pdb -o ${var1}.gro < input_0
gmx editconf -f ${var1}.gro -box 5.76000   4.99000   7.5000 -o ${var1}_boxed.gro
cp ../gold.gro ./

sed -i '1s/xxx/${var1}/' edit_mol_boxed.py #carefull
sed -i '4s/xxx/${var1}/' edit_mol_boxed.py  #carefull
python edit_mol_boxed.py
cat gold.gro edited_${var1}_boxed.gro > system.gro
sed -i '2s/4800/${a}/' system.gro  #4823, since, the ALA has 22 atoms
sed -i '4803d' system.gro
sed -i '4803d' system.gro
sed -i '4803d' system.gro
cp ../topol.top ./
cp ../*itp ./
sed -i '36s/#include "xxx.itp"/#include "${lower}.itp"/' topol.top #carefull
sed -i '4s/end=/end=${a}/' write_posre.py  
python write_posre.py
gmx solvate -cp system.gro -p topol.top -o system_solv.gro
cp ../ions.mdp ./
gmx grompp -f ions.mdp -c system_solv.gro -p topol.top -o ions.tpr
gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral
gmx make_ndx -f solv_ions.gro -o index.ndx < input_1
python ndx.py
python freeze_ndx.py
cat index.ndx ndx.dat freeze_ndx.dat > index_out.ndx
cp -r ../mdp/ ./
mv solv_ions.gro system.gro
mv index_out.ndx index.ndx
EOF
