#PBS -N salt_1M
# request 1 node with 8 cpus each (8 CPUs)
#PBS -l nodes=1:ppn=16
#PBS -l walltime=30:00:00:00
# no mails are sent after completion:
#PBS -m n

#Changes into the directory from where you submitted:
cd ${PBS_O_WORKDIR}

# Set project scratch directory
SCRATCH_TEMP="/scratch/saientan/"   
PROJECT_NAME="ambermaleicacid" 
# mkdir -p $SCRATCH_TEMP
# cp -r ${PBS_O_WORKDIR} ${SCRATCH_TEMP}
# cd ${SCRATCH_TEMP}/${PROJECT_NAME}
cat ${PBS_NODEFILE} # <- all the nodes you requested
export OMP_NUM_THREADS=8


###############################################################################
# Script to run pre simulations and automization of Umbrella Configuration    #
# simulation                    					      #
###############################################################################


echo "Starting with initial equilibration simulations..."

#Erstelle Ordner und kopiere die Ergebnisse in initial simulation ordner
mkdir initial_simulation


#EM Simulation
gmx grompp -f mdp/minim.mdp -c system.gro -p topol.top -n index.ndx -o initial_simulation/em.tpr  
gmx mdrun -deffnm initial_simulation/em 
mv mdout.mdp initial_simulation/mdout_em.mdp

#NVT Simulation
gmx grompp -f mdp/nvt.mdp -c initial_simulation/em.gro -p topol.top -n index.ndx -o initial_simulation/nvt.tpr
gmx mdrun -deffnm initial_simulation/nvt
mv mdout.mdp initial_simulation/mdout_nvt.mdp

echo "Equilibrating into x and y-direction..."

#NPT Simulation
gmx grompp -f mdp/npt_eq.mdp -c initial_simulation/nvt.gro -p topol.top -n index.ndx -o initial_simulation/npt_xyeq.tpr
gmx mdrun -deffnm initial_simulation/npt_xyeq
mv mdout initial_simulation/mdout_npt_xyeq.mdp

   
echo "Determine Mean X and Y values..." 
#Calculate mean value of boxsizes and take a snapshot with that boxsize
rm INPUTFILE.dat
echo "18 19 0" > INPUTFILE.dat
output=$(gmx energy -f initial_simulation/npt_xyeq.edr -b 50 -e 100 -o boxsize.xvg < INPUTFILE.dat)
declare -a average


cnt=0
i=0
while read -r line
do
	if [ "$cnt" -gt 5 ];
	then
		average[i]=$( echo $line | cut -d' ' -f2 ) # save framenumber 
		i=$((i+1))
        fi
	cnt=$((cnt+1))
        
	
done <<< "$output"

boxsize_x=${average[0]} 
boxsize_y=${average[1]}


cnt=0
diffx_last=1
diffy_last=1
boxsize_file="boxsize.xvg"
sed 24d $boxsize_file | { while IFS='' read -r line
do
if [ "$cnt" -gt 24 ];
then	
	frame_time=$( eval "echo $line | cut -d' ' -f1" ) # save framenumber 
	box_x=$( eval "echo $line | cut  -d' ' -f2" )
	box_y=$( eval "echo $line | cut  -d' ' -f3" )

	#Calculate absolute Difference values between Mean Value and Actual Boxsize
	diffx=$( bc <<<"$boxsize_x-$box_x" | awk ' { if($1>=0) { printf "%.6f", $1} else {printf "%.5f", $1*-1 }}' )
	diffy=$( bc <<<"$boxsize_y-$box_y" | awk ' { if($1>=0) { printf "%.6f", $1} else {printf "%.5f", $1*-1 }}' )
	
	#Find the minimal x difference and save frame
	if (( $( bc <<< "$diffx < $diffx_last") ))
	then	
	diffx_last=$diffx
	frame_time_lastx=$frame_time
	fi
	
	#Find the minimal y difference and save frame
	if (( $( bc <<< "$diffy < $diffy_last") ))
	then	
	diffy_last=$diffy
	frame_time_lasty=$frame_time
	fi
fi
cnt=$((cnt+1))	
done < "$boxsize_file"

echo "Take following frame as initial configuration:"
echo $frame_time_lastx
echo $diffx_last
   
   
   # get a snapshot with an average boxsize dimension
gmx trjconv -f initial_simulation/npt_xyeq.trr -s initial_simulation/npt_xyeq.tpr -b $frame_time_lastx -e $frame_time_lastx -o initial_simulation/init_conf.gro < INP_INIT_GROUP0.dat
   
   
} #Close subshell 


#NPT-Simulation
echo "Start simulations with pressure control only in z-direction"
gmx grompp -f mdp/npt.mdp -c initial_simulation/init_conf.gro -n index.ndx -p topol.top -o initial_simulation/npt.tpr
gmx mdrun -deffnm initial_simulation/npt
mv mdout.mdp initial_simulation/mdout_npt.mdp


echo "Start with pulling the molecule to the surface..."

#Erstelle Ordner und kopiere die Ergebnisse in initial simulation ordner
mkdir -p pull


#Pull Molecule on the surface
gmx grompp -f mdp/md_pull_on.mdp -c initial_simulation/npt.gro -p topol.top -n index.ndx -t initial_simulation/npt.cpt -o pull/pull_on.tpr
gmx mdrun -s pull/pull_on
   
   
mv traj.trr pull/traj_on.trr; mv traj_comp.xtc pull/traj_comp_on.xtc ; mv ener.edr pull/ener_on.edr; mv mdout.mdp pull/mdout_pull_on.mdp; mv md.log pull/md_pull_on.log
mv state.cpt pull/state_on.cpt; mv state_prev.cpt pull/state_prev_on.cpt; mv pullf.xvg pull/pullf_on.xvg; mv pullx.xvg pull/pullx_on.xvg ; mv confout.gro pull/confout_pull_on.gro 
   

#Take last Coordinates as gro (last frame 200ps)
gmx trjconv -f pull/traj_on.trr -s pull/pull_on.tpr -b 300 -e 300 -o initial_simulation/system_surface.gro < INP_INIT_GROUP0.dat

echo "Equilibrating the molecule on the surface..."
#Short equilibration EM/NVT/NPT while molecule is on the surface
gmx grompp -f mdp/minim.mdp -c initial_simulation/system_surface.gro -p topol.top -n index.ndx -o initial_simulation/em_surface.tpr
gmx mdrun -deffnm initial_simulation/em_surface
mv mdout.mdp initial_simulation/mdout_emsurface.mdp

gmx grompp -f mdp/nvt.mdp -c initial_simulation/em_surface.gro -p topol.top -n index.ndx -o initial_simulation/nvt_surface.tpr
gmx mdrun -deffnm initial_simulation/nvt_surface
mv mdout.mdp initial_simulation/mdout_nvtsurface.mdp

gmx grompp -f mdp/npt.mdp -c initial_simulation/nvt_surface.gro -p topol.top -n index.ndx -o initial_simulation/npt_surface.tpr
gmx mdrun -deffnm initial_simulation/npt_surface
mv mdout.mdp initial_simulation/mdout_nptsurface.mdp

echo "Pull Molecule off the surface..."

#Pull Molecule off the surface
gmx grompp -f mdp/md_pull_off.mdp -c initial_simulation/npt_surface.gro -p topol.top -n index.ndx -o pull/pull_off.tpr
gmx mdrun -s pull/pull_off
   
mv traj.trr pull/traj_off.trr; mv traj_comp.xtc pull/traj_comp_off.xtc ; mv ener.edr pull/ener_off.edr; mv mdout.mdp pull/mdout_pull_off.mdp; mv md.log pull/md_pull_off.log
mv state.cpt pull/state_off.cpt; mv state_prev.cpt pull/state_prev_off.cpt; mv pullf.xvg pull/pullf_off.xvg; mv pullx.xvg pull/pullx_off.xvg ; mv confout.gro pull/confout_pull_off.gro
   
#Erstelle die Conf.gro Files aus der Trajektorie des Pullings
mkdir -p conf
gmx trjconv -s pull/pull_off.tpr -f pull/traj_comp_off.xtc -o conf/conf.gro -sep < INP_INIT_GROUP0.dat



#Calculate COM distance of Molecule to the surface plane
python calculate_COM_distance.py

#Generate umbrella frames based on the reaction coordinate distances
python SetupUmbrellaFrames.py summary_distances.dat 0.02 &> caught-output.txt


if [[ "${HOSTNAME}" =~ .*int-bionano.int.kit.edu$ ]]
then 
     #Copy result data in output directory
 	cp -r $SCRATCH_TEMP/$PROJECT_NAME/initial_simulation/ ~/Projects/$PROJECT_NAME/
     cp -r $SCRATCH_TEMP/$PROJECT_NAME/conf/ ~/Projects/$PROJECT_NAME/
     cp -r $SCRATCH_TEMP/$PROJECT_NAME/pull/ ~/Projects/$PROJECT_NAME/
     cp $SCRATCH_TEMP/$PROJECT_NAME/caught-output.txt ~/Projects/$PROJECT_NAME/
     cp $SCRATCH_TEMP/$PROJECT_NAME/summary_distances.dat ~/Projects/$PROJECT_NAME/        
fi


#Start Umbrella Sampling Simulations
#cd ~/Projects/$PROJECT_NAME/
#sh ./run_umbrella_sim.sh

