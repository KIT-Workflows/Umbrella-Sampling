import os
    
s='additional/run_1.15/umbrella/us0/pullf-umbrella0.xvg'

if os.path.isfile(s)== False:
    print s

