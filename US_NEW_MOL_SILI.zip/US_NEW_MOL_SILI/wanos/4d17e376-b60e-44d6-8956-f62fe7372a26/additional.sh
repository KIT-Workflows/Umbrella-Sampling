#!/bin/bash

########################################
# Script to run Umbrella simulation    #
# simulation of the zeolite with       #
# dye, water and tryptophan            #
# in alternative configuration         #
########################################

system_label=""

# Read Umbrella Frames from a text file
file="co.txt"


#Read line by line, for every line reading do following
while IFS='' read -r line
        do
        frame_number=$( eval "echo $line | cut -d' ' -f1" ) # save framenumber 
        dist=$( eval "echo $line | cut  -d' ' -f2" )
        d_dist=$( eval "echo $line | cut  -d' ' -f3" )
        delim=","
        parstring="frame_number=${frame_number}"
cat>fh2_sub<<EOF
#!/bin/bash


#Usually you should set
export KMP_AFFINITY=compact,1,0

module load chem/gromacs/2019-ompi





# PBS script to perform umbrella simulation of
# perylene molecule, tetrahydrofuran and graphite
# Name of the Project
echo ${PBS_O_WORKDIR}
#Changes into the directory from where you submitted:
#cd ${PBS_O_WORKDIR}
#cd /home/fh2-project-virtmat/kn1269/adsorption/Gold/CYS/ 
#Do your actual work here, for example:

#Create output directory
mkdir -p umbrella/us${frame_number}/
mkdir -p umbrella/output_mdp/


#Short equilibration
gmx grompp -f mdp/npt_umbrella.mdp -c conf/conf${frame_number}.gro -r conf/conf${frame_number}.gro -p topol.top -n index.ndx -o umbrella/us${frame_number}/npt${frame_number}.tpr -maxwarn 2
gmx mdrun -ntomp 8 -ntmpi 1 -deffnm umbrella/us${frame_number}/npt${frame_number}

# Umbrella run
gmx grompp -f mdp/md_umbrella.mdp -c umbrella/us${frame_number}/npt${frame_number}.gro -r umbrella/us${frame_number}/npt${frame_number}.gro -t umbrella/us${frame_number}/npt${frame_number}.cpt -p topol.top -n index.ndx -o umbrella/us${frame_number}/umbrella${frame_number}.tpr -maxwarn 2
gmx mdrun -ntomp 8 -ntmpi 1 -deffnm umbrella/us${frame_number}/umbrella${frame_number} -pf umbrella/us${frame_number}/pullf-umbrella${frame_number}.xvg -px umbrella/us${frame_number}/pullx-umbrella${frame_number}.xvg
EOF
 
sbatch -p normal --export=ALL,OMP_NUM_THREADS=8 -J ${frame_number} -N 1 -c 2 -t 06:00:00 --mem=6000 fh2_sub
      
	done < $file          
        







