#! /bin/bash

########################################
# Script to run Umbrella simulation    #
# simulation of the zeolite with       #
# dye, water and tryptophan            #
# in alternative configuration         #
########################################

system_label=""

# Read Umbrella Frames from a text file
file="co.txt"


#Read line by line, for every line reading do following
while IFS='' read -r line
        do
        frame_number=$( eval "echo $line | cut -d' ' -f1" ) # save framenumber 
        dist=$( eval "echo $line | cut  -d' ' -f2" )
        d_dist=$( eval "echo $line | cut  -d' ' -f3" )
        delim=","
        parstring="frame_number=${frame_number}" 
        qsub abc.pbs \
            -v ${parstring}  \
            -N ${frame_number}_us_SCRIOT \
            -l nodes=node04.int-bionano.int.kit.edu:ppn=16,walltime=30:00:00:00 \
            -m n \
   

        done < $file 







