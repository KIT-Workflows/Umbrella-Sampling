#!/bin/bash

WORKING_DIR=`pwd`

US_N={{ wano["Tabs"]["General"]["Umbrella Specification"]["Number of Umbrella"] }}
UN_max={{ wano["Tabs"]["General"]["Umbrella Specification"]["Reaction Coordinate Max"] }}
UN_min={{ wano["Tabs"]["General"]["Umbrella Specification"]["Reaction Coordinate Min"] }}


s=`echo "$UN_max - $UN_min" | bc -l`
d=`echo "$s / $US_N" | bc -l`


RC={{ wano["Tabs"]["General"]["Reaction Coordinate Type"] }}
if [ "${RC}" = "distance" ]; then

GR1="{{ wano["Tabs"]["General"]["distance Description"]["Group 1 Name"] }}"
GR2="{{ wano["Tabs"]["General"]["distance Description"]["Group 2 Name"] }}"

fi

for i in $(seq 0 $US_N)

do
di=`echo "$i * $d" | bc -l`
um=`echo "scale=3; $UN_min + $di" | bc -l`
um=`printf "%.3f" $um`
mkdir us_${um}
cd us_${um}
mkdir mdp
cd ..
cp *zip ./us_${um}/
#cp -r ../charmm36-jul2017.ff ./run_${s}/
#cp ../additional.* ./run_${s}/
#cp ../abc.* ./run_${s}/
#cp ../co.txt ./run_${s}/
cp *mdp ./us_${um}/mdp/
cd us_${um}/mdp/
cat>change_mdp.sh<<EOF
sed -i 's/Group1/${GR1}/g' npt_umbrella.mdp
sed -i 's/Group2/${GR2}/g' npt_umbrella.mdp
sed -i 's/Group1/${GR1}/g' md_umbrella.mdp
sed -i 's/Group2/${GR2}/g' md_umbrella.mdp
sed -i 's/pull_coord1_init        = 0.35/pull_coord1_init        = ${um}/g' npt_umbrella.mdp
sed -i 's/pull_coord1_init        = 0.35/pull_coord1_init        = ${um}/g' npt_umbrella.mdp
sed -i 's/pull_coord1_init        = 0.35/pull_coord1_init        = ${um}/g' npt_umbrella.mdp
sed -i 's/pull_coord1_init        = 0.35/pull_coord1_init        = ${um}/g' npt_umbrella.mdp
sed -i 's/pull_coord1_init        = 0.35/pull_coord1_init        = ${um}/g' md_umbrella.mdp
EOF
bash change_mdp.sh
cd ..
cd ..
done

