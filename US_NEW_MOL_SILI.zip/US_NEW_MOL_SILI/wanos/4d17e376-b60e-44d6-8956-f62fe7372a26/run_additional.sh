mkdir umbrella
cd umbrella
for s in 1.0 1.1 1.2 
do
mkdir us_${s}
cd us_${s}
mkdir mdp
cd ..
cp ../*itp ../system.gro ../topol.top ../index.ndx ./us_${s}/
#cp -r ../charmm36-jul2017.ff ./run_${s}/
#cp ../additional.* ./run_${s}/
#cp ../abc.* ./run_${s}/
#cp ../co.txt ./run_${s}/
cp ../*mdp ./us_${s}/mdp/
cd us_${s}/mdp/
cat>change_mdp.sh<<EOF
sed -i '187s/pull_coord1_init        = 0.35/pull_coord1_init        = ${s}/' npt_umbrella.mdp
sed -i '187s/pull_coord1_init        = 0.35/pull_coord1_init        = ${s}/' md_umbrella.mdp
EOF
bash change_mdp.sh
cd ..
cd ..
done
