#!/bin/bash

WORKING_DIR=`pwd`


RC={{ wano["Tabs"]["General"]["Reaction Coordinate Type"] }}
if [ "${RC}" = "distance" ]; then

GR1={{ wano["Tabs"]["General"]["distance Description"]["Group 1 Name"] }}
GR2={{ wano["Tabs"]["General"]["distance Description"]["Group 2 Name"] }}

fi


