r=4.32
s=`echo "$r * $r" | bc -l`
echo $s
s=`echo "$r / 2" | bc -l`
 
echo $s
N=10
for i in $(seq 0 $N)
do
	echo "CAT$i"
done
