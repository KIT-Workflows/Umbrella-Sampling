#!/bin/bash

export NANOVER="V4"
source $NANOMATCH/$NANOVER/configs/ambertools.config


WORKING_DIR=`pwd`

#antechamber
antechamber -i MOL.pdb -fi pdb -at amber -o MOL.mol2  -fo mol2
antechamber -i MOL.mol2 -fi mol2 -at amber -o MOL_bcc.mol2 -fo mol2 -c bcc -nc 0
#parmchk
parmchk2 -i MOL_bcc.mol2 -at amber -f mol2 -o MOL.frcmod
#tleap_script


cat>tleap_script<<EOF
#source /home/ws/kn1269/sources/anaconda3/dat/leap/cmd/oldff/leaprc.ff99SBildn
source leaprc.gaff
loadamberparams MOL.frcmod
a=loadMol2 MOL_bcc.mol2
saveAmberparm a mol.prmtop mol.inpcrd
quit

EOF

#~/sources/anaconda3/bin/tleap -f tleap_script
tleap -f tleap_script

#python2 acpype.py -p mol.prmtop -x mol.inpcrd -b mol -r
python2 acpype.py -p mol.prmtop -x mol.inpcrd -b mol
#mv mol.pdb MOL.pdb
mv mol.prmtop MOL_Amber_Topology.top
#mv mol_GMX.top MOL_GROMACS_Topology.itp
awk '/\[ atomtypes ]/{f=1;n^Ct}/\[ moleculetype ]/{f=0}f' mol_GMX.top > atomtype.itp

mv mol_GMX.top mol.itp

a=$(awk '/moleculetype/{ print NR; exit }' mol.itp)

a=$((a-1))


cat>abc.sh<<EOF

sed -i '1,${a}d' mol.itp

EOF

bash abc.sh

a=$(awk '/system/{ print NR; exit }' mol.itp)

a=$((a-1))

d=$(echo $)


cat>abc.sh<<EOF

sed -i '${a},${d}d' mol.itp

EOF

bash abc.sh



protein=MOL
lower=$(echo $protein | awk '{print tolower($0)}')

ff=$(cat FF)
var1=${protein}
no=$(wc -l sqm.pdb | awk '{ print $1 }')
a=$((no))
var2=`expr 2184 + $a` #Silica no_of_atom + no_of_atom_in var1
cat>abc.sh<<EOF
cp /home/course01/simstack_workspace/Files/Silica/* ./
cp -r /home/course01/simstack_workspace/Files/Silica/mdp ./
mkdir ${var1}
cd ${var1}
cp ../${var1}.pdb ./
cp ../${lower}.itp ./
cp ../input_* ./
cp ../*py ./
cp ../INP* ./
cp ../*sh ./
gmx trjconv -f ${var1}.pdb  -s ${var1}.pdb -o ${var1}.gro < input_0
gmx editconf -f ${var1}.gro -box 3.36000   3.49000   8.5000 -o ${var1}_boxed.gro
cp ../silica.gro ./
cp ../silica.itp ./
cp ../silica_atom_type.itp ./
cp ../posre_silica.itp ./
cp ../atomtype.itp ./
cat silica.gro ${var1}_boxed.gro > system.gro
sed -i '2s/2184/${var2}/' system.gro  
sed -i '2187d' system.gro
sed -i '2187d' system.gro
sed -i '2187d' system.gro
cp ../topol.top ./
sed -i '24s/#include "xxx.itp"/#include "${lower}.itp"/' topol.top          
sed -i '49s/xxx                 1/${lower}                 1/' topol.top 
sed -i 's/forcefield.ff/${ff}.ff/g' topol.top
sed -i '4s/end=/end=${no}/' write_posre.py  
python write_posre.py
gmx solvate -cp system.gro -p topol.top -o system_solv.gro
python code.py
cp ../ions.mdp ./
gmx grompp -f ions.mdp -c system_solv.gro -p topol.top -o ions.tpr -maxwarn 20 
gmx genion -s ions.tpr -o solv_ions.gro -p topol.top -pname NA -nname CL -neutral < input_1

gmx make_ndx -f solv_ions.gro -o index.ndx < input_2
python ndx.py

cp ../si_index.dat ./
cp ../surface_si_index.dat ./
cat index.ndx ndx.dat si_index.dat surface_si_index.dat > index_out.ndx

cp -r ../mdp/ ./
mv solv_ions.gro system.gro
mv index_out.ndx index.ndx
EOF

bash abc.sh
cd MOL
mkdir ITP
cp *itp ./ITP/
tar cvf ITP.tar ITP
cp system.gro topol.top index.ndx ITP.tar ../


