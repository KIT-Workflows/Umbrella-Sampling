#!/bin/bash

WORKING_DIR=`pwd`

module load gromacs

surface={{ wano["Surface_Specification"]["Choose Surface"] }}
if [ "${surface}" = "Graphene" ]; then
cp script_Graphene.sh Surface_Script.sh 
fi
if [ "${surface}" = "Silica" ]; then
cp script_Silica.sh Surface_Script.sh
fi
if [ "${surface}" = "None" ]; then
cp script_None.sh Surface_Script.sh
fi

ff={{ wano["Force Field" ] }}
cat > FF <<EOF
${ff}
EOF
bash Surface_Script.sh





 




