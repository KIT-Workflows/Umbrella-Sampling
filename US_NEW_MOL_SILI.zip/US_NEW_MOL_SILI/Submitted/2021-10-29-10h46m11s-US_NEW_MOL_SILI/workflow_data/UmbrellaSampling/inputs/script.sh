#!/bin/bash

WORKING_DIR=`pwd`

US_N={{ wano["Tabs"]["General"]["Umbrella Specification"]["Number of Umbrella"] }}
UN_max={{ wano["Tabs"]["General"]["Umbrella Specification"]["Reaction Coordinate Max"] }}
UN_min={{ wano["Tabs"]["General"]["Umbrella Specification"]["Reaction Coordinate Min"] }}


s=`echo "$UN_max - $UN_min" | bc -l`
d=`echo "$s / $US_N" | bc -l`

for i in $(seq 0 $US_N)

do
di=`echo "$i * $d" | bc -l`
um=`echo "scale=3; $UN_min + $di" | bc -l`
um=`printf "%.3f" $um`


RC={{ wano["Tabs"]["General"]["Reaction Coordinate Type"] }}
if [ "${RC}" = "distance" ]; then

GR1="{{ wano["Tabs"]["General"]["distance Description"]["Group 1 Name"] }}"
GR2="{{ wano["Tabs"]["General"]["distance Description"]["Group 2 Name"] }}"

cat>us.mdp<<EOF

pull                    = yes
pull_ngroups            = 2
pull_ncoords            = 1
pull_group1_name        = ${GR1}
pull_group2_name        = ${GR2}
pull_coord1_type        = umbrella      ; harmonic biasing force
pull_coord1_geometry    = distance      ; simple distance increase
pull_coord1_groups      = 1 2
pull_coord1_dim         = N N Y
pull_coord1_rate        = 0.0          ; 0.005 nm per ps = 5 nm per ns 2.5 nm pro 500 ps
pull_coord1_k           = 10000          ; kJ mol^-1 nm^-2
pull_coord1_init        = ${um}
pull_coord1_start       = no            ; define initial COM distance > 0

EOF


fi

if [ "${RC}" = "angle" ]; then

GR1="{{ wano["Tabs"]["General"]["angle Description"]["Group 1 Name"] }}"
GR2="{{ wano["Tabs"]["General"]["angle Description"]["Group 2 Name"] }}"
GR3="{{ wano["Tabs"]["General"]["angle Description"]["Group 3 Name"] }}"

cat>us.mdp<<EOF
pull                    = yes
pull_ngroups            = 2
pull_ncoords            = 1
pull_group1_name        = ${GR1}
pull_group2_name        = ${GR2}
pull_group2_name        = ${GR3}
pull_coord1_type        = umbrella      ; harmonic biasing force
pull_coord1_geometry    = distance      ; simple distance increase
pull_coord1_groups      = 1 2
pull_coord1_dim         = N N Y
pull_coord1_rate        = 0.0          ; 0.005 nm per ps = 5 nm per ns 2.5 nm pro 500 ps
pull_coord1_k           = 10000          ; kJ mol^-1 nm^-2
pull_coord1_init        = ${um}
pull_coord1_start       = no            ; define initial COM distance > 0
EOF
fi
if [ "${RC}" = "dihedral" ]; then

GR1="{{ wano["Tabs"]["General"]["dihedral Description"]["Group 1 Name"] }}"
GR2="{{ wano["Tabs"]["General"]["dihedral Description"]["Group 2 Name"] }}"
GR3="{{ wano["Tabs"]["General"]["dihedral Description"]["Group 3 Name"] }}"
GR4="{{ wano["Tabs"]["General"]["dihedral Description"]["Group 4 Name"] }}"
cat>us.mdp<<EOF
pull                    = yes
pull_ngroups            = 2
pull_ncoords            = 1
pull_group1_name        = ${GR1}
pull_group2_name        = ${GR2}
pull_group2_name        = ${GR3}
pull_group2_name        = ${GR4}
pull_coord1_type        = umbrella      ; harmonic biasing force
pull_coord1_geometry    = distance      ; simple distance increase
pull_coord1_groups      = 1 2
pull_coord1_dim         = N N Y
pull_coord1_rate        = 0.0          ; 0.005 nm per ps = 5 nm per ns 2.5 nm pro 500 ps
pull_coord1_k           = 10000          ; kJ mol^-1 nm^-2
pull_coord1_init        = ${um}
pull_coord1_start       = no            ; define initial COM distance > 0
EOF
fi

cp us.mdp us_${um}.mdp

done

