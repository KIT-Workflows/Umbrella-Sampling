#!/bin/bash
set -e
export NANOVER="V4"
source ${NANOMATCH}/${NANOVER}/configs/general.config

module load gromacs


if [[ -f us.mdp ]]
then
   cat us.mdp >> nvt.mdp
fi

if [[ -f ITP.tar ]]
then
   tar -xvf ITP.tar
   cp ITP/* ./
fi

#EM Simulation
gmx grompp -f nvt.mdp -c system.gro -r system.gro -p topol.top -n index.ndx -o gromacs_run.tpr -maxwarn 20
gmx mdrun -ntomp 8 -ntmpi 1 -deffnm gromacs_run


